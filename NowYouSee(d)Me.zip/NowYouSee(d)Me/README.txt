This is an unofficial mod which is not approved nor made by Jason Rohrer
NowYouSee(d)Me-mod v1.0 for One Hour One Life v211
This mod adds indicators and animations for various seeds as well for the hot adobe oven
Made by Mr.XIX

*Installation*
1. Copy the folder 'objects' and 'animations' from 'new' to your OneHourOneLife folder
2. Delete the cache file in 'objects' and 'animations' subfolder of your OneHourOneLife folder

*De�nstalation*
1. Copy the folder 'objects' from 'old' to your OneHourOneLife folder
2. Delete the .txt files from 'animations' with the matching names from the files in 'objects' (this step should delete 5 files per object)
3. Delete the cache files in 'objects' and 'animations' subfolder of your OneHourOneLife folder

Changelog:
v1.0 release