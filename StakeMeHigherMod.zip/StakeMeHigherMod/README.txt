This is an unofficial mod which is not approved nor made by Jason Rohrer
StakeMeHigher-mod v1.3 for One Hour One Life v211
This mod adds an easy to click indicator to your stakes, which makes it easier to cycle trough different stake configurations
Made by Mr.XIX

*Installation*
1. Copy the folder 'objects' and 'animations' from 'new' to your OneHourOneLife folder
2. Delete the cache file in 'objects' and 'animation' subfolder of your OneHourOneLife folder

*De�nstalation*
1. Copy the folder 'objects' and 'animations' from 'old' to your OneHourOneLife folder
2. Delete the cache files in 'objects' and 'animation' subfolder of your OneHourOneLife folder

Changelog:
v1.0 release
v1.1 bugfix no flip flag
v1.2 relocated the indicator to be centered
v1.3 added animation and changed indicator sprite